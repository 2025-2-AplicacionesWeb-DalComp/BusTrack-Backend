namespace ACME.LearningCenterPlatform.API.Profiles.Domain.Model.Query;
/// <summary>
///     Get All Profiles Query
/// </summary>
public record GetAllProfilesQuery();