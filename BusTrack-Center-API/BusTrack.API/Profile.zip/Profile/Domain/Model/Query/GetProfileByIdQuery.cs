namespace ACME.LearningCenterPlatform.API.Profiles.Domain.Model.Query;

public record GetProfileByIdQuery(int ProfileId);