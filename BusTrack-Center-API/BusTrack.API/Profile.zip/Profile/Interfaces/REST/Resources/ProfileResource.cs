namespace ACME.LearningCenterPlatform.API.Profiles.Interfaces.REST.Resources;

public record ProfileResource(int Id, string Username, string Email, string PhotoUrl);